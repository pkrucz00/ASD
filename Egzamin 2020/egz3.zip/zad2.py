from zad2testy import runtests

def tower(A):
  # kod funkcji

  return -1


runtests( tower )
