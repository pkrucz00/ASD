from zad1testy import runtests

def best_root( L ):
    # tu proszę zaimplementować zadanie
    n = len(L)
    return -1


runtests( best_root ) 
