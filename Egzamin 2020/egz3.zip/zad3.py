from zad3testy import runtests

    
def tasks(T):
    # tu prosze wpisac implementacje
    return [i for i in range(len(T))]  # domyslny wynik [0,1,2,... ]



runtests( tasks )
