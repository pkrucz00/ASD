from zad2testy import runtests




def opt_sum(tab):
    # tu prosze wpisac implementacje
    return 0



runtests( opt_sum )
