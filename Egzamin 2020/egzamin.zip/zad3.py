from zad3testy import runtests
import math




                 
    
def fast_sort(tab, a):
    # tu prosze wpisac implementacje
    return tab



runtests( fast_sort )
