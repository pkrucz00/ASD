from zad1testy import runtests



def islands(G, A, B):
    # tu prosze wpisac wlasna implementacje
    pass
        

runtests( islands ) 
